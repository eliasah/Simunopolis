package SwingScala

import scala.swing.SimpleSwingApplication

abstract class SimpleGUIApplication extends SimpleSwingApplication {

}