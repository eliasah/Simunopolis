package simunopolis

import scala.collection.mutable.ArrayBuffer
import simunopolis.Zone

class City(n : String) {
  val name : String = n
  def population(): Int = 0
  def budget(): Double = 20000
  def time() = 0
  var zones = ArrayBuffer[Zone]()
  
  override def toString() : String = {
		  var s = "name :" + name + "\n"
		  for(z <- zones)
		    s+= z + " "
		  return s
  }
  
  def addZone(z: Zone) : Unit = {
    zones.append(z) 
  }
  
}
