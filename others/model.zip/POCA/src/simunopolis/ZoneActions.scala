package simunopolis

trait ZoneActions {

}