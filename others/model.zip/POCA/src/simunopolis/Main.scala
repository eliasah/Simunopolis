package simunopolis

object Main extends App {

  override def main(args: Array[String]) {

    val c = new City("Smallville")

    println(c)

    val rz = new ResidentialZone(10,10)

    c.addZone(rz)
    
    println(c)
  }

}